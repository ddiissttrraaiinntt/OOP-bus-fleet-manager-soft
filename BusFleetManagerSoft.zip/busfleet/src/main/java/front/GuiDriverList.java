package front;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultRowSorter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.RowFilter;
import javax.swing.UIManager;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import org.apache.log4j.Logger;

import com.itextpdf.kernel.PdfException;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

import back_database.DBOperations;
import back_database.Singleton;
import back_entities.EntityDriverList;
import jakarta.persistence.EntityManager;

public class GuiDriverList {
	//фрейм
	private JFrame frame;
	//таблица и ее элементы
	private DefaultTableModel model;
	private String [] columns;
    private String [][] data;
    private JPopupMenu popupMenu;
    private JMenuItem menuItemEdit;
    private int [] selectedRows= {};
	private TableRowSorter<TableModel> sorter;
	//кнопки
	private JButton Export;
	private JButton Add;
	private JButton Delete;
	private JButton Search;
	//панель инструментов
	private JToolBar toolBar;
	private JScrollPane scroll;
	private JTable table;
	private JTextField FilterText;
	//заполнение ячейки текстом
	String CellText;
	private int row;
	private int col;
	//файловый экспорт
	private JFrame exp_frame;
	private JFileChooser fileChooser;
	private FileNameExtensionFilter filter;
	//запись в pdf-файл
	private String check_pdf;
	private PdfWriter writer;
	private PdfDocument pdfDoc;
	private Document doc;
	private Table pdfTable;
	//панель для строки поиска
	private JPanel filterPanel;
    //протоколирование
    private static final Logger log = Logger.getLogger(GuiDriverList.class);
    
    public GuiDriverList() {
    	
		log.info("Screen form creation.");
		frame = new JFrame("Drivers list");
		frame.setSize(1200, 600);
		frame.setLocation(160, 100);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		Export = new JButton(new ImageIcon("./img/Export.png"));
		Add = new JButton(new ImageIcon("./img/Add.png"));
		Delete = new JButton(new ImageIcon("./img/Delete.png"));
		Search = new JButton(new ImageIcon("./img/Search.png"));
		Export.setToolTipText("Export selected lines to a file");
		Add.setToolTipText("Add a line");
		Delete.setToolTipText("Delete selected lines");
		Search.setToolTipText("Search");
		toolBar = new JToolBar("Toolbar");
		toolBar.add(Export);
		toolBar.add(Add);
		toolBar.add(Delete);
		frame.setLayout(new BorderLayout());
		frame.add(toolBar, BorderLayout.NORTH);
		
		//заполнение таблицы
		columns = new String[] {"Full name", "Driver license ID","Experience, years","Driving level"};
		getDBList();
		model = new DefaultTableModel(data, columns);
		
		//запрет на дефолтное редактирование ячеек
	    table = new JTable(model) {
	    	public boolean isCellEditable(int row, int column) {                
	    		return false;               
	        }
	    };
	    
		//всплывающее меню для редактирования ячейки в таблице
        popupMenu = new JPopupMenu();
        menuItemEdit = new JMenuItem("Edit the cell");
        popupMenu.add(menuItemEdit);
        
	    //запрет на дефолтное перемещение столбцов таблицы
	    table.getTableHeader().setReorderingAllowed(false);
	    
	    //сортировка по столбцам
		sorter = new TableRowSorter<TableModel>(model);
		table.setRowSorter(sorter);
		scroll = new JScrollPane(table);
		
		//скроллер
		frame.add(scroll, BorderLayout.CENTER);
		
		//строка поиска по столбцам
		FilterText = new JTextField();
		FilterText.setColumns(30);
		filterPanel = new JPanel();
		filterPanel.add(FilterText);
		filterPanel.add(Search);
		frame.add(filterPanel, BorderLayout.SOUTH);
		
		// добавление слушателей 
		ActionListeners();

    }
	
	private void ActionListeners() {
    	
		//выделение строк
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener(){               
	        public void valueChanged(ListSelectionEvent e) {
	            selectedRows = table.getSelectedRows();
	            table.setComponentPopupMenu(popupMenu);
	         }               
	     });
		
		//сохранение в файл
		Export.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
	    		try {
	    			checkSelection(selectedRows);
	    			log.info("Writing to a PDF file.");
				    log.info("Selecting a PDF file.");
				    exp_frame = new JFrame();
				    fileChooser = new JFileChooser();
				    fileChooser.setDialogTitle("Choose or create the file to write");
					filter = new FileNameExtensionFilter("pdf","pdf");
				    fileChooser.setFileFilter(filter);
				    fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				    int result = fileChooser.showSaveDialog(exp_frame);
				    
				    if (result == JFileChooser.APPROVE_OPTION ) {
				        log.info("PDF file was selected.");
				    	try {	
				    		check_pdf = String.valueOf(fileChooser.getSelectedFile());
				    		check_pdf = remove_substring(check_pdf, ".pdf");
				    		writer = new PdfWriter(check_pdf + ".pdf");
				        	pdfDoc = new PdfDocument (writer);
				        	pdfDoc.addNewPage();
				            doc = new Document(pdfDoc);
				            float [] pointColumnWidths = {150F, 150F, 150F, 150F};
				            pdfTable = new Table(pointColumnWidths);
				            Paragraph paragraph = new Paragraph("Drivers List");
				            pdfTable.addCell("Full name");
				            pdfTable.addCell("Driver license ID");
				            pdfTable.addCell("Experience, years");
				            pdfTable.addCell("Driving level");
				            for (int rows = 0; rows < selectedRows.length; rows++) {
				                for (int cols = 0; cols < table.getColumnCount(); cols++) {
				                    pdfTable.addCell(table.getModel().getValueAt(rows, cols).toString()); 
				                }
				            }
				            doc.add(paragraph);
				            doc.add(pdfTable);
				            doc.close();
				            JOptionPane.showMessageDialog(table,"The table data is saved to a file " + check_pdf +".pdf");
				            log.info("The table data is saved to a file " + check_pdf + ".pdf");
				    	} catch (PdfException ex) {
				    		ex.printStackTrace();
				    	} catch (FileNotFoundException e1) {
				    		JOptionPane.showMessageDialog(table,"File was not found.");
				    		e1.printStackTrace();
				    	} 
				    }
				    else { 
				        	log.warn("To write data to a new file, you must enter its name and click the save button , otherwise writing to the file will not happen.");
				        	log.info("Writing to the file has been canceled.");
				    }
	    		}
	        	catch(MyExceptionDelete myEx) {
	        		JOptionPane.showMessageDialog(table, myEx.getMessage());
	        		myEx.printStackTrace();
	        	}
			}		    
		});
		
		//закрытие окна
		frame.addWindowListener(new WindowAdapter() 
		{
            public void windowClosing(WindowEvent event) {
                Object[] options = { "Yes", "No" };
                int option = JOptionPane.showOptionDialog(event.getWindow(), "Do you want to close this window?",
                                "Confirmation", JOptionPane.YES_NO_OPTION,
                                JOptionPane.INFORMATION_MESSAGE, null, options,
                                options[0]);
                if (option == 0) {
                    event.getWindow().setVisible(false);
                    new GuiMenu().show();
                }
            }
		});
 
		//поиск
	    Search.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	log.info("Table search.");
	        	String text;
	        	text = FilterText.getText();
	        	try {
	        		CheckTextField(text, 10);
	        		((DefaultRowSorter<TableModel, Integer>) sorter).setRowFilter(RowFilter.regexFilter(text));
	        		log.info("The elements were found successfully.");
	        	}
	        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
	        		log.info("Error - an empty input field in the search bar.", myEx);
	        		JOptionPane.showMessageDialog(table, myEx.getMessage());
	        		((DefaultRowSorter<TableModel, Integer>) sorter).setRowFilter(RowFilter.regexFilter(""));
	        	}
	        	finally {
	        		FilterText.setText("");	
	        	}
	      }});
		
		//редактирование ячеек
	    menuItemEdit.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent event){
				log.info("Editing a cell in a table row. ");
				row = table.getSelectedRow();
				col = table.getSelectedColumn();
				String prevname = model.getValueAt(row, 0).toString();
            	String prevdriver = model.getValueAt(row, 1).toString();
        		String prevexp = model.getValueAt(row, 2).toString();
        		String prevlvl = model.getValueAt(row, 3).toString();
				UIManager.put("OptionPane.cancelButtonText", "Cancel");
		        UIManager.put("OptionPane.okButtonText", "Save");
		        
        		switch (col) {
        		case(0):
        			CellText = JOptionPane.showInputDialog(table, "Change to (Ivanov Ivan): ","Edit the full name", JOptionPane.PLAIN_MESSAGE);
		            try{
		            	CheckTextField(CellText, col);
	        			EntityManager em = Singleton.createEMandTrans();
	        			EntityDriverList Driver = DBOperations.searchDriverWithLicense(prevdriver);
	        			Driver.setLicense(CellText);
	            		em.merge(Driver);
	            		Singleton.finishEMandTrans(em);
		            	table.setValueAt(CellText, row, col);
		            	log.info(row +"," + col + "-cell has been edited.");
		            }
		        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		table.setValueAt(prevname, row, col);
	            		log.info("Error - incorrect filling of the cell.", myEx);
	            		log.warn("The contents of the cell will remain the same.", myEx);
	            	}
		            break;
        		case(1):
        			CellText = JOptionPane.showInputDialog(table, "Change to (XXXX XXXXXX): ","Edit the license id", JOptionPane.PLAIN_MESSAGE);
		            try{
		            	CheckTextField(CellText, col);
			            try {
			            	checkRepeat(CellText);
		        			EntityManager em = Singleton.createEMandTrans();
		        			EntityDriverList Driver = DBOperations.searchDriverWithLicense(prevdriver);
		        			Driver.setLicense(CellText);
		            		em.merge(Driver);
		            		Singleton.finishEMandTrans(em);
			            	table.setValueAt(CellText, row, col);
			            	log.info(row +"," + col + "-cell has been edited.");
			            }
		        		catch (RepeatAddException myEx){
		            		UIManager.put("OptionPane.okButtonText", "OK");
		            		JOptionPane.showMessageDialog(table, myEx.getMessage());
		            		log.info("The driver license id field reapeats.", myEx);
		            		log.warn("The new cell will not be added.", myEx);
		        		}
		            }
		        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		table.setValueAt(prevdriver, row, col);
	            		log.info("Error - incorrect filling of the cell.", myEx);
	            		log.warn("The contents of the cell will remain the same.", myEx);
	            	}
		            break;
        		case(2):
        			CellText = JOptionPane.showInputDialog(table, "Change to (0-86 years): ","Edit the experience", JOptionPane.PLAIN_MESSAGE);
		            try{
		            	CheckTextField(CellText, col);
		            	CheckTextField(CellText, col);
						EntityManager em = Singleton.createEMandTrans();
						EntityDriverList Driver = DBOperations.searchDriverWithLicense(prevdriver);
						Driver.setExp(CellText);
						em.merge(Driver);
						Singleton.finishEMandTrans(em);
						table.setValueAt(CellText, row, col);
						log.info(row +"," + col + "-cell has been edited.");
		            }
		        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		table.setValueAt(prevexp, row, col);
	            		log.info("Error - incorrect filling of the cell.", myEx);
	            		log.warn("The contents of the cell will remain the same.", myEx);
	            	}
		            break;
        		case(3):
	        		CellText = JOptionPane.showInputDialog(table, "Change to (1-3): ","Edit the level", JOptionPane.PLAIN_MESSAGE);
		            try{
		            	CheckTextField(CellText, col);
						EntityManager em = Singleton.createEMandTrans();
						EntityDriverList Driver = DBOperations.searchDriverWithLicense(prevdriver);
						Driver.setLvl(CellText);
						em.merge(Driver);
						Singleton.finishEMandTrans(em);
						table.setValueAt(CellText, row, col);
						log.info(row +"," + col + "-cell has been edited.");
		            }
	            	catch(WrongTimeException | EmptyFieldException | WrongFieldException | WrongDateException | EmptySearchFieldException myEx) {
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		table.setValueAt(prevlvl, row, col);
	            		log.info("Error - incorrect filling of the cell.", myEx);
	            		log.warn("The contents of the cell will remain the same.", myEx);
	            	}
		            break;
        		}
			}});
	    
		//добавление новой строки после выделенной
		Add.addActionListener (new ActionListener() {
			public void actionPerformed (ActionEvent event){
				log.info("Adding a new row to the table after the selected one.");
				row = table.getSelectedRow() + 1;
				JTextField add_name = new JTextField();
				JTextField add_driver = new JTextField();
				JTextField add_exp = new JTextField();
				JTextField add_lvl = new JTextField();
				UIManager.put("OptionPane.cancelButtonText", "Cancel");
		        UIManager.put("OptionPane.okButtonText", "Save");
				Object[] message = {
					"Full name (Ivanov Ivan): ", add_name,
					"Driver license ID (XXXX XXXXXX): ", add_driver,
					"Experience (0-86): ", add_exp,
					"Driving level (1-3): ", add_lvl
				};
				int option = JOptionPane.showConfirmDialog(table, message, "New row", JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
				if(option == JOptionPane.OK_OPTION) {
					int exeption_sum = 0;
		            try{
		            	log.info(row +"," + 0 + "-cell is being filled in.");	
		            	CheckTextField(add_name.getText(), 0);
		            }
		        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
		        		exeption_sum++;
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		log.info(row +"," + 0 + "-cell has been filled in wrong.");
	            	}
		            
		            try{
		            	log.info(row +"," + 1 + "-cell is being filled in.");	
		            	CheckTextField(add_driver.getText(), 1);
		            }
		        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
		        		exeption_sum++;
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		log.info(row +"," + 1 + "-cell has been filled in wrong.");
	            	}
		            
		            try{
		            	log.info(row +"," + 2 + "-cell is being filled in.");	
		            	CheckTextField(add_exp.getText(), 2);
		            }
		        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
		        		exeption_sum++;
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		log.info(row +"," + 2 + "-cell has been filled in wrong.");	
	            	}
		            try{
		            	log.info(row +"," + 3 + "-cell is being filled in.");	
		            	CheckTextField(add_lvl.getText(), 3);
		            }
		        	catch( WrongDateException | WrongTimeException | EmptyFieldException | WrongFieldException | EmptySearchFieldException myEx ) {
		        		exeption_sum++;
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		log.info(row +"," + 3 + "-cell has been filled in wrong.");	
	            	}
		            
		            try{
		            	if(exeption_sum > 0) throw new WrongAddException();
		            		try {
		            			checkRepeat(add_driver.getText());
		            			model.insertRow(row, new String [] {add_name.getText(), add_driver.getText(), add_exp.getText(), add_lvl.getText()});
				        		EntityManager em = Singleton.createEMandTrans();
				        		EntityDriverList newDriver = new EntityDriverList(add_name.getText(), add_driver.getText(), add_exp.getText(), add_lvl.getText());
				        		em.persist(newDriver);
				        		Singleton.finishEMandTrans(em);
		            		}
			        		catch (RepeatAddException myEx){
			            		UIManager.put("OptionPane.okButtonText", "OK");
			            		JOptionPane.showMessageDialog(table, myEx.getMessage());
			            		log.info("The driver license id field reapeats.", myEx);
			            		log.warn("The new row will not be added.", myEx);
			        		}
		            }
		            catch(WrongAddException myEx){
	            		UIManager.put("OptionPane.okButtonText", "OK");
	            		JOptionPane.showMessageDialog(table, myEx.getMessage());
	            		log.info("The new line fields were filled in incorrectly.", myEx);
	            		log.warn("The new row will not be added.", myEx);
	        		}
				}
			}
		});	
		
	//удаление строк
	Delete.addActionListener(new ActionListener(){
		public void actionPerformed (ActionEvent event){	
			log.info("Deletion of selected rows from the table.");
			try {
				checkSelection(selectedRows);
				UIManager.put("OptionPane.cancelButtonText", "Cancel");
				UIManager.put("OptionPane.okButtonText", "Confirm");
				int option = JOptionPane.showConfirmDialog(table, "After confirmation, it will be impossible to cancel the deletion of the selected rows.", "Delete?", JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
				log.warn("After confirmation, it will be impossible to cancel the deletion of the selected rows.");
				if (option == JOptionPane.OK_OPTION) {
					UIManager.put("OptionPane.okButtonText", "OK");
			        for(int i = selectedRows.length-1; i > -1; i--){
			        	EntityManager em = Singleton.createEMandTrans();
		        		EntityDriverList Driver = DBOperations.searchDriverWithLicense(String.valueOf(table.getModel().getValueAt(selectedRows[i], 1)));
		        		em.merge(Driver);
		                Singleton.finishEMandTrans(em);
		                model.removeRow(selectedRows[i]);
			        	DBOperations.deleteDriver(Driver.getId());

			        }
			        JOptionPane.showMessageDialog (frame, "The cell data of the selected rows has been deleted from the table.","Deletion message", JOptionPane.PLAIN_MESSAGE);
			        log.info("The selected rows are removed from the table.");
				}
			}
	        catch(MyExceptionDelete myEx) {
	        	JOptionPane.showMessageDialog(table, myEx.getMessage());
	        	log.info("Исключительная ситуация - нет выделенных строк для удаления. ", myEx);
	        	log.warn("Необходимо выделить строки для удаления, иначе удаление будет недоступно. ");
	        }
		}
	});
	}

	//получение данных из БД для таблицы
	private void getDBList() {
		// получение списка из БД
		List<EntityDriverList> Drivers = DBOperations.getSortedDrivers();
		ArrayList<String[]> values = new ArrayList<String[]>(Drivers.size() + 1);
		for (int i = 0; i < Drivers.size(); i++) {
			EntityDriverList entity = Drivers.get(i);
			values.add(new String[]{entity.getName(), entity.getLicense(),entity.getExp(),entity.getLvl()});
		}
        // преобразование в формат для заполнения таблицы данными.
		data = new String[values.size()][4];
		for (int i = 0; i < values.size(); i++) data[i] = values.get(i);
	}
	
    //подсчет подстрок в строке
	public static int count_substring(String str, String target) {
	    return (str.length() - str.replace(target, "").length()) / target.length();
	}
	
    //удаление подстрок в строке
	public static String remove_substring(String str, String substr) {
		int count = count_substring(str, substr);
		if (count > 0) {
			for (int i = 0; i < count; i++)
				str = str.replace(substr, "");
		}
		return str;
	}
	
	//проверка введенного стажа
	public int CheckExpNumber (String text){
		int flag = 0;
		if (Integer.valueOf(text) >= 0 && Integer.valueOf(text) <= 86 ) {
			flag = 1;
		}
		return flag;
	}
	
	//проверка введенного класса вождения
	public int CheckLvlNumber (String text){
		int flag = 0;
		if (Integer.valueOf(text) > 0 && Integer.valueOf(text) <= 3 ) {
			flag = 1;
		}
		return flag;
	}

	//проверка повтора строки
	private void checkRepeat(String str) throws RepeatAddException{
		for (int i = 0; i < table.getRowCount(); i++) {
			if (table.getModel().getValueAt(i, 1).equals(str)) {
				throw new RepeatAddException();
			}
		}
	}

	public class RepeatAddException extends Exception {
		public RepeatAddException() {
			super("It is restricted to add a row with the same driver license id! Please, try again and change this field.");
		}
	}
	
   //обработка заполнения текстового поля 
    public void CheckTextField (String text, int col) throws EmptyFieldException, WrongFieldException, WrongDateException, WrongTimeException, EmptySearchFieldException {
    	if (col == 0 && !text.matches("^[A-Z-][a-z-]* [A-Z-][a-z-]*$")) throw new WrongFieldException(col);
    	if (col == 1 && !text.matches("^\\d{4}\\s\\d{6}$")) throw new WrongFieldException(col);
		if (col != 10 && (text.trim().isEmpty() || text == null) ) throw new EmptyFieldException(col);
		if (col == 10 && (text.trim().isEmpty() || text == null)) throw new EmptySearchFieldException();
		if (col == 2 && (!text.matches("^[1-9]\\d*$") || CheckExpNumber(text) == 0)) throw new WrongFieldException(col);
		if (col == 3 && (!text.matches("^[1-9]\\d*$") || CheckLvlNumber(text) == 0)) throw new WrongFieldException(col);
	}
    
    //поле поиска пустое
	public class EmptySearchFieldException extends Exception {
		public EmptySearchFieldException() {
			super("The search field was empty! Enter the search text again!");
		}
	}
    
    //поле пустое
	public class EmptyFieldException extends Exception {
		public EmptyFieldException(int col) {
			super("The field in the column " + col + " was empty! Fill in the cell again!");
		}
	}
	
	//поле заполнено неверно
	public class WrongFieldException extends Exception {
		public WrongFieldException(int col) {
			super("The field in the column " + col + " was filled in wrong!");
		}
	}
	//время введено неверно
	public class WrongTimeException extends Exception {
		public WrongTimeException() {
			super("The filled in time is wrong! Fill in the cell again and enter an existing time!");
		}
	}
	//дата введена неверно
	public class WrongDateException extends Exception {
		public WrongDateException() {
			super("The filled in date is wrong! Fill in the cell again and enter an existing date!");
		}
	}

    //обработка удаления строк
    public void checkSelection (int[] arr) throws MyExceptionDelete{
    	int len = arr.length;
    	if (len == 0) {
       		throw new MyExceptionDelete();
    	}	
    }
    public class MyExceptionDelete extends Exception {
    	public MyExceptionDelete() {
    	super ("No row selected for deletion or export.");
    	}
    }

    //поля для добавления строки были введены неправильно
    public class WrongAddException extends Exception {
    	public WrongAddException() {
    	super ("The new line fields were filled in incorrectly!");
    	}
    }
    
	//демонстрация окна
	public void show() {
		log.info("Demonstration of a window with a list of drivers.");
		frame.setVisible(true);
	}
    
	public static void main(String[] args) {
		log.info("Demonstration of a window with a list of drivers.");
		new GuiDriverList().show();
	}
}
