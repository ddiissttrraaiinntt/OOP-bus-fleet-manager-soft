package front;

import javax.swing.*;

import org.apache.log4j.Logger;

import java.awt.event.*;

import back_gui.SpringUtilities;

public class GuiMenu {
	//экранная форма
	private JFrame frame;
	//кнопки
	private JButton Drivers;
	private JButton Offences;
	private JButton Routes;
	
    //протоколирование
    private static final Logger log = Logger.getLogger(GuiRouteList.class);
	
	public void show() {
		log.info("Screen form creation.");
		frame = new JFrame("Menu");
		frame.setSize(228, 138);
		frame.setResizable(false);
		frame.setLocation(650, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Drivers = new JButton("            List of Drivers            ");
		Routes = new JButton("            List of Routes            ");
		Offences = new JButton("            List of Offences            ");		
		
		JPanel Panel = new JPanel(new SpringLayout());
		
		Panel.add(Drivers);
		Panel.add(Routes); 
		Panel.add(Offences);
		
		SpringUtilities.makeCompactGrid(Panel,3,1,6, 6, 6, 6);
		frame.add(Panel);
		
		log.info("Button actions' creation.");
		Drivers.addActionListener(new ActionListener()
		{
			public void actionPerformed (ActionEvent event)
			{
				new GuiDriverList().show();
				frame.setVisible(false);
			}
		} );
		
		Routes.addActionListener(new ActionListener()
		{
			public void actionPerformed (ActionEvent event)
			{
				new GuiRouteList().show();
				frame.setVisible(false);
			}
		} );
	
		
		Offences.addActionListener(new ActionListener()
		{
			public void actionPerformed (ActionEvent event)
			{
				new GuiOffenceList().show();
				frame.setVisible(false);
			}
		} );
		
		frame.setVisible(true);
	}
	public static void main(String[] args) {
		new GuiMenu().show();
	}

}
