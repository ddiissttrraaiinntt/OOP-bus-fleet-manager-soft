package back_entities;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import back_database.DBOperations;
import back_database.Singleton;

@Entity
@Table(name="route")
public class EntityRouteList {
	
	//id маршрута
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int route_id; 
	//название
	@Column(name="name")
	private String name;
	//начало движения 
	@Column(name="start_time")
	private String time1;
	//конец движения 
	@Column(name="end_time")
	private String time2;
	//остановки и график
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "id_route", cascade = CascadeType.ALL)
	private List<EntityStationList> Stations = new ArrayList<>();

	
	//конструктор класса
	public EntityRouteList(String name, String time1, String time2) {
		this.name = name;
		this.time1 = time1;
		this.time2 = time2;
	}
	// дефолтный конструктор класса
	public EntityRouteList() {
		this.name = "";
		this.time1 = "";
		this.time2 = "";
	}
	
	//геттеры
	public int getId() {
		return route_id;
	}
	
	public String getName() {
		return name;
	}

	public String getStart() {
		return time1;
	}
	
	public String getEnd() {
		return time2;
	}
	
	// сеттеры
	public void setName(String new_name) {
		this.name = new_name;
	}
	
	public void setStart(String new_time1) {
		this.time1 = new_time1;
	}
	
	public void setEnd(String new_time2) {
		this.time2 = new_time2;
	}
	
	//геттер списка остановок
	public List<EntityStationList> getSts() {
//		EntityManager em = Singleton.createEMandTrans();
		Stations = DBOperations.getStations(name);
//		em.merge(Stations);
//		Singleton.finishEMandTrans(em);
		return Stations;
	}
	
}
