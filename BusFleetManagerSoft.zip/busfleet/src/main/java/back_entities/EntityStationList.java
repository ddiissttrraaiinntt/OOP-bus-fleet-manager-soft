package back_entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="station")
public class EntityStationList {
	//id остановки
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int station_id; 
	//название
	@Column(name="name")
	private String name;
	//начало движения на остановке
	@Column(name="start_time")
	private String time1;
	//конец движения на остановке
	@Column(name="end_time")
	private String time2;
	//интервалы движения:
	//до 10:00
	@Column(name="to10")
	private String int10;
	//до 16:00
	@Column(name="to16")
	private String int16;
	//до 20:00
	@Column(name="to20")
	private String int20;
	//до 20:00
	@Column(name="past20")
	private String int00;
	//id маршрута
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_route")
	private EntityRouteList id_route;  
	
	//конструктор класса
	public EntityStationList(String name, String time1, String time2, String int10, String int16, String int20, String int00, EntityRouteList route) {
		this.name = name;
		this.time1 = time1;
		this.time2 = time2;
		this.int10 = int10;
		this.int16 = int16;
		this.int20 = int20;
		this.int00 = int00;
		this.id_route = route;
	}
	// дефолтный конструктор класса
	public EntityStationList() {
		this.name = "";
		this.time1 = "";
		this.time2 = "";
		this.int10 = "";
		this.int16 = "";
		this.int20 = "";
		this.int00 = "";
		this.id_route = null;
	}
	
	//геттеры
	public int getId() {
		return station_id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getStart() {
		return time1;
	}
	
	public String getEnd() {
		return time2;
	}
	
	public String getInt1() {
		return int10;
	}
	
	public String getInt2() {
		return int16;
	}
	
	public String getInt3() {
		return int20;
	}
	
	public String getInt4() {
		return int00;
	}
	
	public EntityRouteList getRoute() {
		return id_route;
	}
	
	// сеттеры
	public void setName(String new_name) {
		this.name = new_name;
	}

	public void setStart(String new_time1) {
		this.time1 = new_time1;
	}
	
	public void setEnd(String new_time2) {
		this.time2 = new_time2;
	}
	
	public void setInt1(String new_int1) {
		this.int10 = new_int1;
	}
	
	public void setInt2(String new_int2) {
		this.int16 = new_int2;
	}
	
	public void setInt3(String new_int3) {
		this.int20 = new_int3;
	}
	
	public void setInt4(String new_int4) {
		this.int00 = new_int4;
	}
	
	public void setRoute(EntityRouteList new_route) {
		this.id_route = new_route;
	}
}

