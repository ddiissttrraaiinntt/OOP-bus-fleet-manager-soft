package back_entities;

import java.util.ArrayList;
import java.util.List;

import back_database.DBOperations;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="driver")
public class EntityDriverList {
	//id водителя = номер прав
	@Id
	@Column(name="id")
	private int driver_id;
	//Ф.И.О
	@Column(name="name")
	private String name; 
	//права
	@Column(name="license")
	private String license; 
	//стаж работы
	@Column(name="experience")
	private String exp;
	//класс
	@Column(name="level")
	private String lvl;
	//массив штрафов
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "id_driver", cascade = CascadeType.ALL)
	private List<EntityOffenceList> Offences = new ArrayList<>();
	
	//конструктор класса
	public EntityDriverList(String name, String license, String exp, String lvl) {
		this.name = name;
		this.license = license;
		this.exp = exp;
		this.lvl = lvl;
	}
	// дефолтный конструктор класса
	public EntityDriverList() {
		this.name = "";
		this.license = "";
		this.exp = "";
		this.lvl = "";
	}
	
	//геттеры
	public int getId() {
		return driver_id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getLicense() {
		return license;
	}
	
	public String getExp() {
		return exp;
	}
	
	public String getLvl() {
		return lvl;
	}
	
	// сеттеры
	
	public void setName(String new_name) {
		this.license = new_name;
	}
	
	public void setLicense(String new_license) {
		this.license = new_license;
	}

	public void setExp(String new_exp) {
		this.exp = new_exp;
	}
	
	public void setLvl(String new_lvl) {
		this.lvl = new_lvl;
	}
	
	//геттер списка штрафов
	public List<EntityOffenceList> getOffs() {
		Offences = DBOperations.getOffences(license);
		return Offences;
	}
	
}

