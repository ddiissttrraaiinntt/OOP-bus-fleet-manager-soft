package back_entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="offence")
public class EntityOffenceList {
	//id нарушения
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int offence_id; 
	//дата 
	@Column(name="date")
	private String date;
	//время 
	@Column(name="time")
	private String time;
	//номер прав водителя
	@Column(name="driver")
	private String driver;
	//Ф.И.О водителя
	@Column(name="name")
	private String name; 
	//маршрут
	@Column(name="route")
	private String route;
	//задержка
	@Column(name="delay")
	private String delay;
	//id водителя из таблицы
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_driver")
	private EntityDriverList id_driver;  
	
	//конструктор класса
	public EntityOffenceList( String name, String driver, String date, String time, String route, String delay, EntityDriverList id_driver) {
		this.name = name;
		this.driver = driver;
		this.date = date;
		this.time = time;
		this.route = route;
		this.delay = delay;
		this.id_driver = id_driver;
	}
	// дефолтный конструктор класса
	public EntityOffenceList() {
		this.name = "";
		this.driver = "";
		this.date = "";
		this.time = "";
		this.route = "";
		this.delay = "";
		this.id_driver = null;
	}
	
	//геттеры
	public int getId() {
		return offence_id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDate() {
		return date;
	}
	
	public String getTime() {
		return time;
	}
	
	public String getDriver() {
		return driver;
	}
	
	public String getRoute() {
		return route;
	}
	
	public String getDelay() {
		return delay;
	}
	
	public EntityDriverList getIdDriver() {
		return id_driver;
	}
	
	// сеттеры
	public void setName(String new_name) {
		this.name = new_name;
	}
	
	public void setDate(String new_date) {
		this.date = new_date;
	}
	
	public void setTime(String new_time) {
		this.time = new_time;
	}
	
	public void setDriver(String new_driver) {
		this.driver = new_driver;
	}
	
	public void setRoute(String new_route) {
		this.route = new_route;
	}

	public void setDelay(String new_delay) {
		this.delay = new_delay;
	}
	
	public void setIdDriver(EntityDriverList new_id_driver) {
		this.id_driver = new_id_driver;
	}
}
