package back_gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.EventObject;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;

import front.GuiRouteList;
import front.GuiStationList;

public class ButtonEditor extends DefaultCellEditor {
	  protected JButton button;

	  public static String label;

	  private boolean isPushed;

	private GuiRouteList guiRouteList1;
	  

	  public ButtonEditor(GuiRouteList guiRouteList, JCheckBox checkBox) {
	    super(checkBox);
	    guiRouteList1 = guiRouteList;
	    button = new JButton();
	    button.setOpaque(true);
	    button.addActionListener(new ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        fireEditingStopped();
	      }
	    });
	  }


	public Component getTableCellEditorComponent(JTable table, Object value,
	      boolean isSelected, int row, int column) {
	    if (isSelected) {
	      button.setForeground(table.getSelectionForeground());
	      button.setBackground(table.getSelectionBackground());
	    } else {
	      button.setForeground(table.getForeground());
	      button.setBackground(table.getBackground());
	    }
	    label = (value == null) ? "" : value.toString();
	    button.setText(label);
	    isPushed = true;
	    return button;
	  }

      public void windowClosing(WindowEvent event) {
              event.getWindow().setVisible(false);
          }
  
	  public Object getCellEditorValue() {
	    if (isPushed) {
	    	guiRouteList1.close();
	    	GuiStationList guiStationList = new GuiStationList(label);
	    	guiStationList.show();
	    }
	    isPushed = false;
	    return new String(label);
	  }

	public boolean stopCellEditing() {
	    isPushed = false;
	    return super.stopCellEditing();
	  }

	  protected void fireEditingStopped() {
	    super.fireEditingStopped();
	  }
	}
