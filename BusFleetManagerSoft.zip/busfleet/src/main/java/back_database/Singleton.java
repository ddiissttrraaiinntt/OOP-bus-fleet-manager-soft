package back_database;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

//Синглтон для использования единого во всем проекте EntityManagerFactory,
//а также общей работы с EntityManager.

public class Singleton {     
	//Экземпляр класса
	private static Singleton instance = null;     
	//Фабрика EntityManager для работы с БД
	private EntityManagerFactory emf;   
	
	//Создание фабрики
	private Singleton() {         
		emf = Persistence.createEntityManagerFactory("test_persistence");
	}   
	
	//Cоздание фабрики или получение экземпляра класса с уже созданной фабрикой
	public static Singleton getInstance() {         
		if (instance == null) {
			instance = new Singleton();         
		}         
		return instance;     
	}      
	
	//Получение фабрики
	public EntityManagerFactory getEntityManagerFactory() {         
		return emf;     
	}
	
	// Создание интерфейса для работы с БД и открытие транзакции
	public static EntityManager createEMandTrans() {
		EntityManager em = getInstance().getEntityManagerFactory().createEntityManager();
		em.getTransaction().begin();
		return em;
	}
	
	//Закрытие интерфейса и транзации
	public static void finishEMandTrans(EntityManager em) {
		em.getTransaction().commit();
		em.close();
	}
}

