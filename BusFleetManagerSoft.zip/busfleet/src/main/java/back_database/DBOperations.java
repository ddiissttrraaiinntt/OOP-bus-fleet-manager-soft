package back_database;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import back_entities.EntityDriverList;
import back_entities.EntityOffenceList;
import back_entities.EntityRouteList;
import back_entities.EntityStationList;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

public class DBOperations {	
	
	//отсортированный  список нарушений
	//использование: выгрузка данных из БД в таблицу
	public static List<EntityOffenceList> getSortedOffences() {
		EntityManager em = Singleton.createEMandTrans(); // создание объекта
		CriteriaBuilder cb = em.getCriteriaBuilder(); // создание объекта запроса, изменяется подробностями запроса
		CriteriaQuery<EntityOffenceList> cq = cb.createQuery(EntityOffenceList.class);
		Root<EntityOffenceList> root = cq.from(EntityOffenceList.class); // корень запроса
		cq.orderBy(cb.asc(root.get("driver")));
		List<EntityOffenceList> Offences = em.createQuery(cq).getResultList();
		Singleton.finishEMandTrans(em);
		return Offences;
	}
	
	//отсортированный список номеров прав водителей
	//нарушения: заполнение выпадаюших списков 
	public static String[] getSortedLicences() {
		List<EntityDriverList> Drivers = getSortedDrivers();
		List<String> licencesList = new ArrayList<String>();
		licencesList = Drivers.stream().map(EntityDriverList::getLicense).collect(Collectors.toList());
		licencesList = new ArrayList<>(new HashSet<>(licencesList));
		String[] licenses = licencesList.toArray(new String[licencesList.size()]);
		Arrays.sort(licenses);
		return licenses;
	}
	
	//отсортированный  список маршрутов
	//нарушения: заполнение выпадаюших списков 
	public static String[] getSortedRouteNames() {
		List<EntityRouteList> routesList = getSortedRoutes();
		List<String> rnamesList = new ArrayList<String>();
		rnamesList = routesList.stream().map(EntityRouteList::getName).collect(Collectors.toList());
		rnamesList = new ArrayList<>(new HashSet<>(rnamesList));
		String[] rnames = rnamesList.toArray(new String[rnamesList.size()]);
		Arrays.sort(rnames);
		return rnames;
	}
	
	//получение водителя по номеру прав
	//использование: 
	//нарушения: дабавление строки в БД
	//водители: сохранение после редактирования ячейки, удаление
	public static EntityDriverList searchDriverWithLicense(String license) {
		EntityManager em = Singleton.createEMandTrans();
		Query qSess = em.createQuery("SELECT u FROM EntityDriverList u WHERE u.license = :license ");
		qSess.setParameter("license", license);
		EntityDriverList result = (EntityDriverList) qSess.getResultList().get(0);
		return result;
	}
	
	//получение нарушения по номеру прав, дате и времени
	//использование: сохранение после редактирования ячейки, удаление
	public static EntityOffenceList searchOffence(String date, String time, String driver) {
		EntityManager em = Singleton.createEMandTrans();
		Query qSess = em.createQuery("SELECT u FROM EntityOffenceList u WHERE u.date = :date "
				+ "AND u.time = :time AND u.driver = :driver");
		qSess.setParameter("date", date);
		qSess.setParameter("time", time);
		qSess.setParameter("driver", driver);
		EntityOffenceList result = (EntityOffenceList) qSess.getResultList().get(0);
		return result;
	}
	
	//удаление нарушений по id
	public static void deleteOffence(int offence_id){
		EntityManager em = Singleton.createEMandTrans();
		Query offences =  em.createQuery("DELETE FROM EntityOffenceList e WHERE e.id = :offence_id");
		offences.setParameter("offence_id", offence_id);
		offences.executeUpdate();
		Singleton.finishEMandTrans(em);
	}
	
	//отсортированный  список водителей
	//использование: выгрузка данных из БД в таблицу
	public static List<EntityDriverList> getSortedDrivers() {
		EntityManager em = Singleton.createEMandTrans();
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<EntityDriverList> cq = cb.createQuery(EntityDriverList.class);
		Root<EntityDriverList> root = cq.from(EntityDriverList.class);
		cq.orderBy(cb.asc(root.get("license")));
		List<EntityDriverList> Drivers = em.createQuery(cq).getResultList();
		Singleton.finishEMandTrans(em);
		return Drivers;
	}
	
	//удаление водителей по id
	public static void deleteDriver(int driver_id){
		EntityManager em = Singleton.createEMandTrans();
		Query drivers =  em.createQuery("DELETE FROM EntityDriverList e WHERE e.id = :driver_id");
		drivers.setParameter("driver_id", driver_id);
		drivers.executeUpdate();
		Singleton.finishEMandTrans(em);
	}
	
	//отсортированный  список маршрутов
	//использование: выгрузка данных из БД в таблицу
	public static List<EntityRouteList> getSortedRoutes() {
		EntityManager em = Singleton.createEMandTrans();
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<EntityRouteList> cq = cb.createQuery(EntityRouteList.class);
		Root<EntityRouteList> root = cq.from(EntityRouteList.class);
		cq.orderBy(cb.asc(root.get("name")));
		List<EntityRouteList> Routes = em.createQuery(cq).getResultList();
		Singleton.finishEMandTrans(em);
		return Routes;
	}
	
	//получение маршрута по названию
	//использование: 
	//маршруты: сохранение после редактирования ячейки, удаление
	//остановки: дабавление строки в БД
	public static EntityRouteList searchRouteWithName(String name) {
		EntityManager em = Singleton.createEMandTrans();
		Query qSess = em.createQuery("SELECT u FROM EntityRouteList u WHERE u.name = :name ");
		qSess.setParameter("name", name);
		EntityRouteList result = (EntityRouteList) qSess.getResultList().get(0);
		return result;
	}
	
	//удаление маршрутов по id
	public static void deleteRoute(int route_id){
		EntityManager em = Singleton.createEMandTrans();
		Query routes =  em.createQuery("DELETE FROM EntityRouteList e WHERE e.id = :route_id");
		routes.setParameter("route_id", route_id);
		routes.executeUpdate();
		Singleton.finishEMandTrans(em);
	}
	
	//отсортированный  список остановок
	//использование: выгрузка данных из БД в таблицу
	public static List<EntityStationList> getSortedStations() {
		EntityManager em = Singleton.createEMandTrans();
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<EntityStationList> cq = cb.createQuery(EntityStationList.class);
		Root<EntityStationList> root = cq.from(EntityStationList.class);
		cq.orderBy(cb.asc(root.get("name")));
		List<EntityStationList> Stations = em.createQuery(cq).getResultList();
		Singleton.finishEMandTrans(em);
		return Stations;
	}
	
	//получение остановок по названию
	//использование: сохранение после редактирования ячейки, удаление
	public static EntityStationList searchStationWithName(String name) {
		EntityManager em = Singleton.createEMandTrans();
		Query qSess = em.createQuery("SELECT u FROM EntityStationList u WHERE u.name = :name ");
		qSess.setParameter("name", name);
		EntityStationList result = (EntityStationList) qSess.getResultList().get(0);
		return result;
	}
	
	//удаление остановок по id
	public static void deleteStation(int station_id){
		EntityManager em = Singleton.createEMandTrans();
		Query stations =  em.createQuery("DELETE FROM EntityStationList e WHERE e.id = :station_id");
		stations.setParameter("station_id", station_id);
		stations.executeUpdate();
		Singleton.finishEMandTrans(em);
	}
	
	//получение списка остановок по названию маршрута
	//использование: получение массива остановок в классе EntityRouteList
	public static List<EntityStationList> getStations(String routename) {
		EntityRouteList OneRoute = DBOperations.searchRouteWithName(routename);
		List<EntityStationList> Stations = DBOperations.getSortedStations();
		List<EntityStationList> arrStations = new ArrayList<>();
		for (int i = 0; i < Stations.size(); i++) {
			EntityStationList entity = Stations.get(i);
			if(entity.getRoute().getId() == OneRoute.getId()) {
				arrStations.add(entity);
			}
		}
		return arrStations;
	}

	//получение списка нарушений по номеру прав водителя
	//использование: получение массива нарушений в классе EntityDriverList
	public static List<EntityOffenceList> getOffences(String license) {
		EntityDriverList OneDriver = DBOperations.searchDriverWithLicense(license);
		List<EntityOffenceList> Offences = DBOperations.getSortedOffences();
		List<EntityOffenceList> arrOffences = new ArrayList<>();
		for (int i = 0; i < Offences.size(); i++) {
			EntityOffenceList entity = Offences.get(i);
			if(entity.getIdDriver().getId() == OneDriver.getId()) {
				arrOffences.add(entity);
			}
		}
		return arrOffences;
	}

}

